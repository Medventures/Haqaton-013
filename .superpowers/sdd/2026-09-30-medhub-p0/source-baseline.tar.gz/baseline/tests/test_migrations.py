from pathlib import Path

from alembic import command
from alembic.config import Config
from sqlalchemy import create_engine, text


def test_template_migration_preserves_existing_consultation_and_backfills_default(tmp_path: Path, monkeypatch):
    backend_dir = Path(__file__).resolve().parents[1]
    url = f"sqlite:///{tmp_path / 'old.db'}"
    monkeypatch.setenv("DATABASE_URL", url)
    config = Config(str(backend_dir / "alembic.ini"))
    config.set_main_option("script_location", str(backend_dir / "alembic"))
    command.upgrade(config, "0001_initial")

    engine = create_engine(url)
    with engine.begin() as connection:
        connection.execute(text("INSERT INTO users (id, username, password_hash, role, display_name) VALUES ('user-1', 'doctor', 'hash', 'doctor', 'Doctor')"))
        connection.execute(text("INSERT INTO consultations (id, external_patient_id, status, created_by, created_at, updated_at) VALUES ('consult-1', 'SYN-1', 'CREATED', 'user-1', '2026-01-01', '2026-01-01')"))

    command.upgrade(config, "head")
    with engine.connect() as connection:
        assert connection.scalar(text("SELECT template_id FROM consultations WHERE id='consult-1'")) == "therapist"
        assert connection.scalar(text("SELECT approved_by_name FROM consultations WHERE id='consult-1'")) is None

    command.downgrade(config, "0001_initial")
    command.upgrade(config, "head")
    with engine.connect() as connection:
        assert connection.scalar(text("SELECT template_id FROM consultations WHERE id='consult-1'")) == "therapist"
    engine.dispose()
