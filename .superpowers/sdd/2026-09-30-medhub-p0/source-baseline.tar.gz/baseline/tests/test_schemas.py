import pytest
from pydantic import ValidationError

from app.schemas import ConsultationData, Medication, TranscriptSegment


def test_document_rejects_unexpected_clinical_fields():
    with pytest.raises(ValidationError):
        ConsultationData.model_validate({"invented_treatment": "anything"})


def test_draft_defaults_do_not_invent_medical_information():
    draft = ConsultationData()
    assert draft.diagnosis is None
    assert draft.medications == []
    assert draft.prescribed_medications == []
    assert draft.vital_signs is None


def test_medication_requires_nonblank_name():
    with pytest.raises(ValidationError):
        Medication(name=" ")


def test_segment_rejects_reversed_time():
    with pytest.raises(ValidationError):
        TranscriptSegment(start=5, end=2, text="Синтетический пример")


def test_specialty_values_are_retained_without_inventing_defaults():
    data = ConsultationData.model_validate({"template_fields": [
        {"key": "status_localis", "value": "Уточнение врача"},
        {"key": "growth", "value": None},
    ]})
    assert data.model_dump()["template_fields"][0]["value"] == "Уточнение врача"
    assert data.model_dump()["template_fields"][1]["value"] is None
