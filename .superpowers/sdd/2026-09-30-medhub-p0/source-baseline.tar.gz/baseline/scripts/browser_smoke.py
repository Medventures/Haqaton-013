"""Synthetic browser acceptance test. Requires running API and Vite servers.

Install playwright separately, then set MEDHUB_BROWSER_EXECUTABLE if using an
existing Chromium executable. This creates a clearly labelled demo consultation.
"""

import json
import os
import re
import time
import zipfile
from pathlib import Path

from playwright.sync_api import expect, sync_playwright


def main():
    output = Path(os.getenv("MEDHUB_QA_OUTPUT", "/tmp/medhub-qa"))
    output.mkdir(parents=True, exist_ok=True)
    patient = f"SYNTHETIC-QA-{int(time.time())}"
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(
            headless=True,
            executable_path=os.getenv("MEDHUB_BROWSER_EXECUTABLE") or None,
        )
        context = browser.new_context(viewport={"width": 1440, "height": 1000})
        page = context.new_page()
        page.set_default_timeout(15000)
        errors = []
        page.on("pageerror", lambda error: errors.append(str(error)))
        page.goto(os.getenv("MEDHUB_BASE_URL", "http://127.0.0.1:5173"))
        page.get_by_label("Логин", exact=True).fill("doctor")
        page.get_by_label("Пароль", exact=True).fill("demo-doctor")
        page.get_by_role("button", name="Войти", exact=True).click()
        page.get_by_role("button", name="Новая консультация", exact=True).first.click()
        page.get_by_label("ID пациента", exact=True).fill(patient)
        expect(page.get_by_role("combobox", name="Бланк консультации", exact=True)).to_have_value("therapist")
        expect(page.get_by_role("combobox", name="Бланк консультации", exact=True).locator("option")).to_have_count(6)
        page.get_by_role("button", name="Создать", exact=True).click()
        page.get_by_role("button", name="Использовать синтетический пример").click()
        page.get_by_role("button", name="Сформировать черновик", exact=True).click()
        diagnosis = page.locator("#field-diagnosis")
        expect(diagnosis).to_have_value(re.compile("бронхит"))
        expect(page.get_by_role("button", name="Подтвердить", exact=True)).to_be_disabled()
        diagnosis.fill("Синтетическое заключение после проверки врачом")
        specialty = page.locator(".specialty-field textarea").first
        specialty.fill("Синтетические сведения <проверено> & сохранено")
        # Test the supplied catalog through a physician's explicit choice.
        search = page.get_by_placeholder("Поиск по коду или названию")
        search.fill("J20.9")
        page.get_by_role("option", name="J20.9", exact=False).first.click()
        page.screenshot(path=str(output / "workspace-draft.png"))
        page.get_by_role("button", name="Сохранить проверку", exact=True).click()
        expect(page.get_by_role("button", name="Подтвердить", exact=True)).to_be_enabled()
        saved_url = page.url
        page.reload()
        expect(diagnosis).to_have_value("Синтетическое заключение после проверки врачом")
        expect(specialty).to_have_value("Синтетические сведения <проверено> & сохранено")
        assert page.url == saved_url
        page.get_by_role("button", name="Подтвердить", exact=True).click()
        expect(page.get_by_role("button", name="Скачать DOCX")).to_be_visible()
        expect(diagnosis).to_be_disabled()
        with page.expect_download() as download_event:
            page.get_by_role("button", name="Скачать DOCX").click()
        download_path = output / "approved-consultation.docx"
        download_event.value.save_as(download_path)
        with zipfile.ZipFile(download_path) as docx:
            xml = docx.read("word/document.xml").decode("utf-8")
        assert "Синтетическое заключение после проверки врачом" in xml
        assert "&lt;проверено&gt; &amp; сохранено" in xml
        assert "J20.9" in xml
        page.get_by_role("button", name="Отправить в mock МИС").click()
        expect(page.get_by_role("heading", name="Передано в mock МИС")).to_be_visible()
        page.evaluate("window.scrollTo(0,0)")
        page.screenshot(path=str(output / "workspace-approved.png"))
        page.set_viewport_size({"width": 390, "height": 844})
        page.wait_for_function("document.querySelector('.sidebar').getBoundingClientRect().right <= 1")
        page.screenshot(path=str(output / "workspace-mobile.png"))
        assert page.evaluate("document.documentElement.scrollWidth <= window.innerWidth"), "Mobile horizontal overflow"
        assert not errors, errors
        print(json.dumps({"status": "passed", "patient": patient, "url": saved_url,
                          "checks": ["login", "six templates", "synthetic draft", "ICD search",
                                     "specialty edits", "save and reload", "approval guard",
                                     "DOCX XML content", "mock MIS", "mobile overflow", "no JS errors"],
                          "artifacts": str(output)}, ensure_ascii=False))
        browser.close()


if __name__ == "__main__":
    main()
