import { cleanup, render, screen } from '@testing-library/react'
import { afterEach, expect, it } from 'vitest'
import { RuntimeNotice } from './RuntimeNotice'

afterEach(cleanup)

it('discloses OpenAI transmission even when demo login is enabled', () => {
  render(<RuntimeNotice demo externalAI />)
  expect(screen.getByText(/отправляется в OpenAI/)).toBeInTheDocument()
  expect(screen.getByText(/публичный тестовый пароль/)).toBeInTheDocument()
  expect(screen.queryByText(/Внешние сервисы не вызываются/)).not.toBeInTheDocument()
})

it('does not advertise OpenAI when the fixture provider is active', () => {
  render(<RuntimeNotice demo externalAI={false} />)
  expect(screen.getByText(/встроенном примере/)).toBeInTheDocument()
  expect(screen.queryByText(/отправляется в OpenAI/)).not.toBeInTheDocument()
})

it('discloses external generation on the login screen too', () => {
  render(<RuntimeNotice demo externalAI compact />)
  expect(screen.getByText(/отправляется в OpenAI/)).toBeInTheDocument()
})
