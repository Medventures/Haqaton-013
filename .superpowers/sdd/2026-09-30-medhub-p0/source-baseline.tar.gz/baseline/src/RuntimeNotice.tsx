import { FlaskConical, Sparkles } from 'lucide-react'

export function RuntimeNotice({ demo, externalAI, compact = false }: { demo: boolean; externalAI: boolean; compact?: boolean }) {
  if (!demo && !externalAI) return null
  const title = externalAI ? 'OpenAI подключён' : 'Демонстрационный режим'
  const description = externalAI
    ? 'При генерации текст после автоматического маскирования отправляется в OpenAI. Маскирование может пропустить персональные данные.'
    : 'Генерация работает только на встроенном примере. Для своей записи подключите OpenAI.'
  const content = <span><strong>{title}</strong> · {description}{demo && ' Используется публичный тестовый пароль: только локальная проверка, не рабочая система.'}</span>
  const icon = externalAI ? <Sparkles size={18} /> : <FlaskConical size={18} />
  if (compact) return <div className="demo-login-note">{icon}{content}</div>
  return <div className="demo-banner"><div>{icon}{content}</div><span className="demo-pill">{externalAI ? 'OPENAI' : 'DEMO'}</span></div>
}
