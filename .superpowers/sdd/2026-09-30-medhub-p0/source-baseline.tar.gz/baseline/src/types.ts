export type Status = 'CREATED' | 'RECORDING' | 'PROCESSING' | 'TRANSCRIBED' | 'AI_GENERATED' | 'REVIEWED' | 'APPROVED' | 'SENT_TO_MIS' | 'FAILED'

export interface User { id: string; username: string; role: 'doctor' | 'admin'; display_name: string }
export interface Health { status: 'ok'; mode: 'demo' | 'live'; stt_model: string; llm_provider: 'demo' | 'openai'; llm_model: string; mis_provider: 'mock' }
export interface TemplateField { key: string; label: string; prompt: string; section: string; clinical_field?: string | null }
export interface ConsultationTemplate { id: string; name: string; fields: TemplateField[] }
export interface Consultation { id: string; external_patient_id: string; template_id: string; status: Status; created_at: string; updated_at: string; approved_at: string | null; error_message: string | null }
export interface TranscriptSegment { start: number; end: number; text: string; speaker: string | null }
export interface Transcript { raw_text: string; normalized_text: string; masked_text: string; language: string; duration_seconds: number; stt_model: string; segments: TranscriptSegment[]; pii_entities: { type: string; placeholder: string }[] }
export interface Medication { name: string; dosage: string | null; frequency: string | null; duration: string | null }
export interface VitalSigns { temperature: string | null; blood_pressure: string | null; heart_rate: string | null; respiratory_rate: string | null; oxygen_saturation: string | null }
export interface ClinicalData {
  complaints: string[]
  anamnesis_morbi: string | null
  anamnesis_vitae: string | null
  allergies: string[]
  medications: Medication[]
  vital_signs: VitalSigns | null
  objective_status: string | null
  diagnosis: string | null
  diagnosis_code: string | null
  recommendations: string[]
  prescribed_medications: Medication[]
  additional_notes: string | null
  template_fields: { key: string; value: string | null }[]
}
export interface Document { id: string; consultation_id: string; ai_generated_data: ClinicalData; doctor_approved_data: ClinicalData | null; data: ClinicalData; llm_provider: string; llm_model: string; updated_at: string; version: number }
export interface AuditEntry { id: string; field: string; ai_value: unknown; doctor_value: unknown; changed: boolean; created_at: string }
export interface ExportResult { success: boolean; document_id: string; provider: 'mock' }
