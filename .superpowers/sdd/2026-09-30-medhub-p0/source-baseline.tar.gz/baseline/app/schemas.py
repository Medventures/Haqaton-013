"""Shared clinical contracts. Unknown fields are rejected at every boundary."""

from enum import StrEnum
from typing import Annotated, Self

from pydantic import BaseModel, ConfigDict, Field, StringConstraints, model_validator


ShortText = Annotated[str, StringConstraints(strip_whitespace=True, min_length=1, max_length=500)]
LongText = Annotated[str, StringConstraints(strip_whitespace=True, max_length=10000)]


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_assignment=True)


class ConsultationStatus(StrEnum):
    CREATED = "CREATED"
    RECORDING = "RECORDING"
    PROCESSING = "PROCESSING"
    TRANSCRIBED = "TRANSCRIBED"
    AI_GENERATED = "AI_GENERATED"
    REVIEWED = "REVIEWED"
    APPROVED = "APPROVED"
    SENT_TO_MIS = "SENT_TO_MIS"
    FAILED = "FAILED"


class Medication(StrictModel):
    name: ShortText
    dosage: ShortText | None = None
    frequency: ShortText | None = None
    duration: ShortText | None = None


class VitalSigns(StrictModel):
    temperature: ShortText | None = None
    blood_pressure: ShortText | None = None
    heart_rate: ShortText | None = None
    respiratory_rate: ShortText | None = None
    oxygen_saturation: ShortText | None = None


class TemplateFieldValue(StrictModel):
    key: str = Field(min_length=1, max_length=100, pattern=r"^[a-zA-Z0-9_.-]+$")
    value: LongText | None = None


class ConsultationData(StrictModel):
    complaints: list[ShortText] = Field(default_factory=list, max_length=100)
    anamnesis_morbi: LongText | None = None
    anamnesis_vitae: LongText | None = None
    allergies: list[ShortText] = Field(default_factory=list, max_length=100)
    medications: list[Medication] = Field(default_factory=list, max_length=100)
    vital_signs: VitalSigns | None = None
    objective_status: LongText | None = None
    diagnosis: LongText | None = None
    diagnosis_code: Annotated[str, StringConstraints(strip_whitespace=True, to_upper=True, min_length=3, max_length=16, pattern=r"^[A-Z0-9.]+$")] | None = None
    recommendations: list[ShortText] = Field(default_factory=list, max_length=100)
    prescribed_medications: list[Medication] = Field(default_factory=list, max_length=100)
    additional_notes: LongText | None = None
    template_fields: list[TemplateFieldValue] = Field(default_factory=list, max_length=200)


class TranscriptSegment(StrictModel):
    start: float = Field(ge=0, allow_inf_nan=False)
    end: float = Field(ge=0, allow_inf_nan=False)
    text: str = Field(max_length=20000)
    speaker: ShortText | None = None

    @model_validator(mode="after")
    def ordered_times(self) -> Self:
        if self.end < self.start:
            raise ValueError("Segment end must not precede its start")
        return self


class Transcript(StrictModel):
    language: str = Field(min_length=2, max_length=12)
    duration: float = Field(ge=0, allow_inf_nan=False)
    segments: list[TranscriptSegment] = Field(default_factory=list, max_length=50000)
    stt_model: ShortText = "unknown"

    @property
    def raw_text(self) -> str:
        return " ".join(segment.text.strip() for segment in self.segments).strip()


class PIIEntity(StrictModel):
    type: str = Field(min_length=1, max_length=50)
    placeholder: str = Field(min_length=1, max_length=100)


class MaskedTranscript(StrictModel):
    text: str = Field(max_length=500000)
    entities: list[PIIEntity] = Field(default_factory=list)


class MISResult(StrictModel):
    success: bool
    document_id: str = Field(min_length=1, max_length=200)
    provider: str = "mock"
