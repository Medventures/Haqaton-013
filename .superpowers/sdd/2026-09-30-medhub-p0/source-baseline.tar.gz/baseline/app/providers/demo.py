"""Clearly labelled synthetic fixture; never a fallback for uploaded audio."""

from app.normalization import normalize_transcript
from app.providers.base import ProviderError
from app.schemas import ConsultationData, Medication, Transcript, TranscriptSegment, VitalSigns


_DEMO_TEXT = (
    "Врач: Что вас беспокоит? "
    "Пациент: Сухой кашель, слабость и температура до 38 градусов. "
    "Симптомы появились три дня назад. Принимал парацетамол 500 мг. "
    "Врач: Предварительный диагноз — острый бронхит."
)

DEMO_TRANSCRIPT = Transcript(
    language="ru",
    duration=34.0,
    stt_model="synthetic-demo",
    segments=[TranscriptSegment(start=0.0, end=34.0, text=_DEMO_TEXT, speaker=None)],
)


class DemoLLMProvider:
    async def extract_consultation(
        self, transcript: str, *, template_fields: list[dict] | None = None
    ) -> ConsultationData:
        if normalize_transcript(transcript) != normalize_transcript(DEMO_TRANSCRIPT.raw_text):
            raise ProviderError("Демо-извлечение поддерживает только синтетический пример.")
        return ConsultationData(
            complaints=["сухой кашель", "слабость", "температура до 38 градусов"],
            anamnesis_morbi="Симптомы появились три дня назад.",
            medications=[Medication(name="Парацетамол", dosage="500 мг")],
            vital_signs=VitalSigns(temperature="до 38 градусов"),
            diagnosis="Предварительный диагноз: острый бронхит",
        )
