"""Medical scribe backend."""
